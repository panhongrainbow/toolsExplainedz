var http = require("http");
var url = require("url");
var cardManagementVersion="1.1.3";
//var querystring = require('querystring'); 
var child_process = require('child_process');
var logger = require('../hipkilog');
const fs=require('fs');
var errorcode = require("../errorcode");
var EXEC_FAIL_TIMEOUT=0x7600000D;

var handlers = {
   "/CardManagement/": serverInfo,
   "/CardManagement/popupForm":popupForm,
   "/CardManagement/CMCPopForm":CMCPopForm,
   "/CardManagement/sendCardCommand":sendCardCommand,
};
function outputDirect(response, msg){
	response.writeHead(200, {"Content-Type": "text/plain; charset=utf-8"});
	response.write(msg);
	response.end();
}
function CMCPopForm(request,response){
	var whiteList=fs.readFileSync(__dirname+'/whiteListCM.txt', 'utf8').split(/\r\n|\r|\n/);
	var matchstr=whiteList[0];
	for(i=1;i<whiteList.length;i++){
		matchstr=matchstr+"|"+whiteList[i];
	}
	response.writeHead(200, {"Content-Type": "text/html; charset=utf-8"});
	var htm=fs.readFileSync(__dirname+'/CMCPopForm.htm','utf8');
	htm=htm.replace(/%matchstr%/g,matchstr);
	response.write(htm);
	response.end();
}

function popupForm(request,response){
	var whiteList=fs.readFileSync(__dirname+'/whiteListCM.txt', 'utf8').split(/\r\n|\r|\n/);
	var matchstr=whiteList[0];
	for(i=1;i<whiteList.length;i++){
		matchstr=matchstr+"|"+whiteList[i];
	}
	response.writeHead(200, {"Content-Type": "text/html; charset=utf-8"});
	var htm=fs.readFileSync(__dirname+'/popupFormCM.htm','utf8');
	htm=htm.replace(/%matchstr%/g,matchstr);
	response.write(htm);
	response.end();
}

function serverInfo(request,response)
{
	response.writeHead(200, {"Content-Type": "text/plain"});
	response.write('Card Management. Version '+cardManagementVersion);
	response.end();
}
function sendCardCommand(request,response)
{
	logger.info("In sendCardCommand");
	var exedir = __dirname;
	if(process.cwd().toUpperCase() === "C:\\Windows\\system32".toUpperCase()){
		exedir = process.env.HOME;
		//response.write("service\n");
	}else{
		//response.write("standalone\n");
	}
	logger.info("In sendCardCommand-->process.cwd():"+process.cwd()+" exedir:"+exedir+" request.method:"+request.method);
	if (request.method == 'POST') {
		var body = '';
		request.on('data', function (data) {
			body += data;
		});
		request.on('end', function () {
			try{
				//allPost = querystring.parse(body);
				//var params=JSON.parse(allPost["tbsPackage"]);
				body=decodeURIComponent(body);
				allPost=body.substr(body.indexOf("=")+1);	
				params=JSON.parse(allPost);				
				//console.log('request: ' + allPost["tbsPackage"]);
				//var param=allPost["tbsPackage"];
				var stdout=child_process.execFileSync(exedir+"/xOUC.exe", [JSON.stringify(params)], {"encoding": 'utf8', "timeout": 900000});
				console.log('stdout: ' + stdout);
				logger.info(stdout);
				var outData=JSON.parse(stdout);
				outputDirect(response,JSON.stringify(outData));
				//var resultJson = JSON.stringify(outData);
				//return resultJson;
			}catch(error){
				console.log('exec error: ' + error);
				logger.error(error);
				var output={};
				output["ret_code"]=EXEC_FAIL_TIMEOUT;
				output["message"]=errorcode.MajorErrorReason(EXEC_FAIL_TIMEOUT);
				outputDirect(response,JSON.stringify(output));
			}
		});
	} else {
		var cMsg="Request method error";
		console.log(cMsg);
		logger.error(cMsg);
		var output={};
		output["ret_code"]=0x7600000C;
		output["message"]=cMsg;
		outputDirect(response,JSON.stringify(output));	
	}
	logger.info("out sendCardCommand");
}
function handle(pathname, query, response) {
    //Check pathname has its request handlers
    if (typeof handlers[pathname] === "function") {
        handlers[pathname](query, response);
		return;
    }
	//No matched handler return 404
	console.log("No request handler for this pathname: '" + pathname + "'");
	response.writeHead(404, {"Content-Type": "text/plain"});
	response.write("404 Not found");
	response.end();
}

exports.handle=handle;